﻿using System;

namespace Store
{
	public class CatalogService
	{
		
	}
}
